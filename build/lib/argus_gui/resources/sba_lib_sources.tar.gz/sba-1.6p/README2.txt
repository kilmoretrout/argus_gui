This directory is version 1.6 of the SBA library (see README.TXT) plus the libsbaproj extension (see libsbaproj/README.txt)
along with the Makefiles used to build the libraries for Linux, MacOS and Windows. See the other READMEs for details on
licensing and so on.

Ty Hedrick
2016-03-17
